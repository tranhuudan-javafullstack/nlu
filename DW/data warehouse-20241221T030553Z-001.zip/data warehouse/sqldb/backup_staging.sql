-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: localhost    Database: staging_weather
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daily_snapshot`
--

DROP TABLE IF EXISTS `daily_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_snapshot` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total_row` int DEFAULT NULL,
  `total_time` time DEFAULT NULL,
  `avg_time` time DEFAULT NULL,
  `avg_row` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_snapshot`
--

LOCK TABLES `daily_snapshot` WRITE;
/*!40000 ALTER TABLE `daily_snapshot` DISABLE KEYS */;
INSERT INTO `daily_snapshot` VALUES (1,'2023-12-15','2023-12-15 00:00:00','2023-12-15 00:00:00',5120,'00:09:41','00:04:51',2560),(2,'2023-12-16','2023-12-16 00:00:00','2023-12-16 05:51:28',5120,'00:06:15','00:03:08',2560);
/*!40000 ALTER TABLE `daily_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weather_data`
--

DROP TABLE IF EXISTS `weather_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weather_data` (
  `dt` text COLLATE utf8mb4_unicode_ci,
  `visibility` text COLLATE utf8mb4_unicode_ci,
  `pop` text COLLATE utf8mb4_unicode_ci,
  `dt_txt` text COLLATE utf8mb4_unicode_ci,
  `name` text COLLATE utf8mb4_unicode_ci,
  `lat` text COLLATE utf8mb4_unicode_ci,
  `lon` text COLLATE utf8mb4_unicode_ci,
  `country` text COLLATE utf8mb4_unicode_ci,
  `province_name` text COLLATE utf8mb4_unicode_ci,
  `district_name` text COLLATE utf8mb4_unicode_ci,
  `sunrise` text COLLATE utf8mb4_unicode_ci,
  `sunset` text COLLATE utf8mb4_unicode_ci,
  `timezone` text COLLATE utf8mb4_unicode_ci,
  `population` text COLLATE utf8mb4_unicode_ci,
  `weather_main` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon_url` text COLLATE utf8mb4_unicode_ci,
  `created_at` text COLLATE utf8mb4_unicode_ci,
  `along_time` text COLLATE utf8mb4_unicode_ci,
  `main_temp` text COLLATE utf8mb4_unicode_ci,
  `main_feels_like` text COLLATE utf8mb4_unicode_ci,
  `main_temp_min` text COLLATE utf8mb4_unicode_ci,
  `main_temp_max` text COLLATE utf8mb4_unicode_ci,
  `main_pressure` text COLLATE utf8mb4_unicode_ci,
  `main_sea_level` text COLLATE utf8mb4_unicode_ci,
  `main_grnd_level` text COLLATE utf8mb4_unicode_ci,
  `main_humidity` text COLLATE utf8mb4_unicode_ci,
  `main_temp_kf` text COLLATE utf8mb4_unicode_ci,
  `clouds_all` text COLLATE utf8mb4_unicode_ci,
  `wind_speed` text COLLATE utf8mb4_unicode_ci,
  `wind_deg` text COLLATE utf8mb4_unicode_ci,
  `wind_gust` text COLLATE utf8mb4_unicode_ci,
  `sys_pod` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_main_aqi` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_components_co` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_components_no` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_components_no2` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_components_o3` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_components_so2` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_components_pm2_5` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_components_pm10` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_components_nh3` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_dt` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_dt_txt` text COLLATE utf8mb4_unicode_ci,
  `air_pollution_along_time` text COLLATE utf8mb4_unicode_ci,
  `rain_3h` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weather_data`
--

LOCK TABLES `weather_data` WRITE;
/*!40000 ALTER TABLE `weather_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `weather_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-16  6:42:30
