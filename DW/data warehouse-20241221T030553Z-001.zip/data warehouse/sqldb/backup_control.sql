-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: localhost    Database: control
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `data_checkpoints`
--

DROP TABLE IF EXISTS `data_checkpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_checkpoints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data_upto_date` timestamp NULL DEFAULT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `is_inserted` bit(1) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_checkpoints`
--

LOCK TABLES `data_checkpoints` WRITE;
/*!40000 ALTER TABLE `data_checkpoints` DISABLE KEYS */;
INSERT INTO `data_checkpoints` VALUES (1,'crawl dữ liệu buổi sáng','crawl','CP1','2023-10-17 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'Group1','Checkpoint1','CP1','2023-01-01 00:00:00','Test Checkpoint','2023-01-01 00:00:00','2023-01-01 00:00:00','TestUser','TestUser',NULL,NULL,NULL,NULL),(3,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'2','openweather api','CP1','2023-12-12 11:03:00','Bắt đầu chạy','2023-12-12 11:03:00','2023-12-12 11:03:00','huudan','huudan','',NULL,NULL,NULL),(5,'2','openweather api','CP1','2023-12-12 11:03:35','Hoàn thành','2023-12-12 11:03:35','2023-12-12 11:04:16','huudan','huudan','',NULL,NULL,NULL),(6,'2','openweather api','CP1','2023-12-12 11:06:15','Hoàn thành','2023-12-12 11:06:15','2023-12-12 11:06:51','huudan','huudan','',NULL,NULL,NULL),(7,'2','openweather api','CP1','2023-12-13 11:48:50','Hoàn thành','2023-12-12 11:48:50','2023-12-12 11:49:29','huudan','huudan','',NULL,NULL,NULL),(8,'2','openweather api','CP1','2023-12-12 20:54:26','Hoàn thành','2023-12-12 20:54:26','2023-12-12 20:55:48','huudan','huudan','',NULL,NULL,NULL),(9,'2','openweather api','CP1','2023-12-12 20:58:22','Bắt đầu chạy','2023-12-12 20:58:22','2023-12-12 20:58:22','huudan','huudan','',NULL,NULL,NULL),(10,'2','openweather api','CP1','2023-12-12 20:58:49','Bắt đầu chạy','2023-12-12 20:58:49','2023-12-12 20:58:49','huudan','huudan','',NULL,NULL,NULL),(11,'2','openweather api','CP1','2023-12-12 21:02:02','Bắt đầu chạy','2023-12-12 21:02:02','2023-12-12 21:02:02','huudan','huudan','',NULL,NULL,NULL),(12,'2','openweather api','CP1','2023-12-12 21:03:44','Hoàn thành','2023-12-12 21:03:44','2023-12-12 21:04:28','huudan','huudan','',NULL,NULL,NULL),(13,'2','openweather api','CP1','2023-12-12 21:07:12','Hoàn thành','2023-12-12 21:07:12','2023-12-12 21:07:55','huudan','huudan','',NULL,NULL,NULL),(14,'2','openweather api','CP1','2023-12-12 21:09:22','Bắt đầu chạy','2023-12-12 21:09:22','2023-12-12 21:09:22','huudan','huudan','',NULL,NULL,NULL),(15,'2','openweather api','CP1','2023-12-12 21:09:26','Hoàn thành','2023-12-12 21:09:26','2023-12-12 21:10:16','huudan','huudan','',NULL,NULL,NULL),(16,'Raw data','openweather api','CP1','2023-12-15 21:13:07','Hoàn thành','2023-12-13 21:13:07','2023-12-12 21:15:38','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-12/2023-12-12_2023-12-17_4.csv','raw/2023-12-13/2023-12-13_2023-12-18_0.csv',NULL,NULL),(17,'Raw data','openweather api','CP1','2023-12-15 15:29:18','Hoàn thành','2023-12-14 15:29:18','2023-12-13 15:32:33','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-13/2023-12-13_2023-12-18_0.csv','raw/2023-12-13/2023-12-13_2023-12-18_0.csv',NULL,NULL),(18,'Raw data','openweather api','CP1','2023-12-20 13:30:43','Hoàn thành','2023-12-15 13:30:44','2023-12-15 13:34:24','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-15/2023-12-15_2023-12-20_0.csv','raw/2023-12-15/2023-12-15_2023-12-20_0.csv',_binary '\0',NULL),(19,'Raw data','openweather api','CP1','2023-12-20 13:55:50','Hoàn thành','2023-12-15 13:55:50','2023-12-15 13:58:32','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-15/2023-12-15_2023-12-20_1_0.csv','raw/2023-12-15/2023-12-15_2023-12-20_1_0.csv',_binary '\0',NULL),(20,'Raw data','openweather api','CP1','2023-12-20 14:00:13','Hoàn thành','2023-12-15 14:00:14','2023-12-15 14:03:41','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-15/2023-12-15_2023-12-20_2_0.csv','raw/2023-12-15/2023-12-15_2023-12-20_2_0.csv',_binary '\0',NULL),(21,'Raw data','openweather api','CP1','2023-12-20 14:08:35','Hoàn thành','2023-12-15 14:08:35','2023-12-15 14:12:13','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-15/2023-12-15_2023-12-20_3_0.csv','raw/2023-12-15/2023-12-15_2023-12-20_3_0.csv',_binary '\0',NULL),(22,'Raw data','openweather api','CP1','2023-12-15 14:16:21','Bắt đầu chạy','2023-12-15 14:16:21','2023-12-15 14:16:21','huudan','huudan','','',_binary '\0',NULL),(23,'Raw data','openweather api','CP1','2023-12-15 14:18:37','Bắt đầu chạy','2023-12-15 14:18:37','2023-12-15 14:18:37','huudan','huudan','','',_binary '\0',NULL),(24,'Raw data','openweather api','CP1','2023-12-15 14:19:02','Bắt đầu chạy','2023-12-15 14:19:02','2023-12-15 14:19:02','huudan','huudan','','',_binary '\0',NULL),(25,'Raw data','openweather api','CP1','2023-12-20 14:19:12','Hoàn thành','2023-12-15 14:19:13','2023-12-15 14:22:34','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-15/2023-12-15_14:19:12_2023-12-20_0.csv','raw/2023-12-15/2023-12-15_14:19:12_2023-12-20_0.csv',_binary '\0',NULL),(26,'Raw data','openweather api','CP1','2023-12-15 14:31:13','Bắt đầu chạy','2023-12-15 14:31:13','2023-12-15 14:31:13','huudan','huudan','','',_binary '\0',NULL),(27,'Raw data','openweather api','CP1','2023-12-15 14:33:10','Bắt đầu chạy','2023-12-15 14:33:10','2023-12-15 14:33:10','huudan','huudan','','',_binary '\0',NULL),(28,'Raw data','openweather api','CP1','2023-12-15 14:36:45','Bắt đầu chạy','2023-12-15 14:36:45','2023-12-15 14:36:45','huudan','huudan','','',_binary '\0',NULL),(29,'Raw data','openweather api','CP1','2023-12-15 14:51:56','Bắt đầu chạy','2023-12-15 14:51:56','2023-12-15 14:51:56','huudan','huudan','','',_binary '\0',NULL),(30,'Raw data','openweather api','CP1','2023-12-15 14:55:55','Bắt đầu chạy','2023-12-15 14:55:55','2023-12-15 14:55:55','huudan','huudan','','',_binary '\0',NULL),(31,'Raw data','openweather api','CP1','2023-12-15 14:56:19','Bắt đầu chạy','2023-12-15 14:56:19','2023-12-15 14:56:19','huudan','huudan','','',_binary '\0',NULL),(32,'Raw data','openweather api','CP1','2023-12-15 14:58:55','Bắt đầu chạy','2023-12-15 14:58:55','2023-12-15 14:58:55','huudan','huudan','','',_binary '\0',NULL),(33,'Raw data','openweather api','CP1','2023-12-15 15:05:09','Bắt đầu chạy','2023-12-15 15:05:09','2023-12-15 15:05:09','huudan','huudan','','',_binary '\0',NULL),(34,'Raw data','openweather api','CP1','2023-12-15 15:12:58','Bắt đầu chạy','2023-12-15 15:12:58','2023-12-15 15:12:58','huudan','huudan','','',_binary '\0',NULL),(35,'Raw data','openweather api','CP1','2023-12-15 15:14:56','Bắt đầu chạy','2023-12-15 15:14:56','2023-12-15 15:14:56','huudan','huudan','','',_binary '\0',NULL),(36,'Raw data','openweather api','CP1','2023-12-20 15:48:38','Hoàn thành','2023-12-15 15:48:38','2023-12-15 15:54:13','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-15/2023-12-15_15:48:38_2023-12-20_0.csv','raw/2023-12-15/2023-12-15_15:48:38_2023-12-20_0.csv',_binary '\0',NULL),(37,'Raw data','openweather api','CP1','2023-12-16 06:56:27','Bắt đầu chạy','2023-12-16 06:56:27','2023-12-16 06:56:27','huudan','huudan','','',_binary '\0',NULL),(38,'Raw data','openweather api','CP1','2023-12-21 06:57:35','đã excute file lên staging','2023-12-16 06:57:35','2023-12-16 07:00:36','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-16/2023-12-16_06:57:35_2023-12-21_0.csv','raw/2023-12-16/2023-12-16_06:57:35_2023-12-21_0.csv',_binary '','2023-12-16 13:10:02'),(39,'Raw data','openweather api','CP1','2023-12-21 12:48:20','đã di chuyển file thành công','2023-12-16 12:48:21','2023-12-16 12:51:20','huudan','huudan','https://doruryrxte9jp.cloudfront.net/raw/2023-12-16/2023-12-16_12:48:20_2023-12-21_0.csv','raw/2023-12-16/2023-12-16_12:48:20_2023-12-21_0.csv',_binary '\0','2023-12-16 13:03:31');
/*!40000 ALTER TABLE `data_checkpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_file_configs`
--

DROP TABLE IF EXISTS `data_file_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_file_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `source_path` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `location` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `separator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `columns` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `destination` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `backup_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sourcetination` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `code` (`code`) USING BTREE,
  CONSTRAINT `c` FOREIGN KEY (`code`) REFERENCES `data_checkpoints` (`code`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_file_configs`
--

LOCK TABLES `data_file_configs` WRITE;
/*!40000 ALTER TABLE `data_file_configs` DISABLE KEYS */;
INSERT INTO `data_file_configs` VALUES (1,'thoitiet.vn','CP1','trang web thời tiết','/warehouse/data_file/','https://thoitiet.vn','csv',',',NULL,'{\n  \"user\": \"root\",\n  \"password\": \"123\",\n  \"host\": \"localhost\",\n  \"database\": \"warehosue\"\n}',NULL,NULL,NULL,NULL,'/warehouse/backup_data_file/','{\n  \"user\": \"root\",\n  \"password\": \"123\",\n  \"host\": \"localhost\",\n  \"database\": \"staging\"\n}');
/*!40000 ALTER TABLE `data_file_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_files`
--

DROP TABLE IF EXISTS `data_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_files` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `row_count` bigint DEFAULT NULL,
  `df_config_id` int DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `file_timestamp` timestamp NULL DEFAULT NULL,
  `data_range_from` timestamp NULL DEFAULT NULL,
  `data_range_to` timestamp NULL DEFAULT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `updated_by` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `df` (`df_config_id`) USING BTREE,
  CONSTRAINT `data_files_ibfk_1` FOREIGN KEY (`df_config_id`) REFERENCES `data_file_configs` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_files`
--

LOCK TABLES `data_files` WRITE;
/*!40000 ALTER TABLE `data_files` DISABLE KEYS */;
INSERT INTO `data_files` VALUES (5,'Test File update 121',0,1,'Bắt đầu chạy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:29:17','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:29:17','2023-12-12 10:29:17','huudan','huudan'),(7,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:31:10','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:31:10','2023-12-12 10:31:10','huudan','huudan'),(8,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:32:40','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:32:40','2023-12-12 10:32:40','huudan','huudan'),(9,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:34:13','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:34:13','2023-12-12 10:34:13','huudan','huudan'),(10,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:38:30','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:38:30','2023-12-12 10:38:30','huudan','huudan'),(11,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:38:42','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:38:42','2023-12-12 10:38:42','huudan','huudan'),(12,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:39:03','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:39:03','2023-12-12 10:39:03','huudan','huudan'),(13,'Test File update 121',0,1,'Bắt đầu chạy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:45:03','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:45:03','2023-12-12 10:45:03','huudan','huudan'),(15,'file_name',NULL,1,'Bắt đầu chạy','2023-12-12 10:46:15','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:46:15','2023-12-12 10:46:15','huudan','huudan'),(16,'file_name',NULL,1,'Bắt đầu chạy','2023-12-12 10:46:38','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:46:38','2023-12-12 10:46:38','huudan','huudan'),(17,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:46:42','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:46:42','2023-12-12 10:46:42','huudan','huudan'),(18,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:48:18','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:48:18','2023-12-12 10:48:18','huudan','huudan'),(19,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:48:57','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:48:57','2023-12-12 10:48:57','huudan','huudan'),(20,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:50:33','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:50:33','2023-12-12 10:50:33','huudan','huudan'),(21,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:57:06','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:57:06','2023-12-12 10:57:06','huudan','huudan'),(22,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:57:43','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:57:43','2023-12-12 10:57:43','huudan','huudan'),(23,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:58:34','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:58:34','2023-12-12 10:58:34','huudan','huudan'),(24,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 10:58:38','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 10:58:38','2023-12-12 10:58:38','huudan','huudan'),(25,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 11:00:49','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 11:00:49','2023-12-12 11:00:49','huudan','huudan'),(26,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 11:03:00','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 11:03:00','2023-12-12 11:03:00','huudan','huudan'),(27,'2023-12-12_2023-12-17.csv',40,1,'Hoàn thành','2023-12-12 11:04:16','2023-12-12 06:00:00','2023-12-17 03:00:00','Hoàn thành','2023-12-12 11:03:35','2023-12-12 11:04:16','huudan','huudan'),(28,'2023-12-12_2023-12-17.csv',40,1,'Hoàn thành','2023-12-12 11:06:50','2023-12-12 06:00:00','2023-12-17 03:00:00','Hoàn thành','2023-12-12 11:06:15','2023-12-12 11:06:50','huudan','huudan'),(29,'2023-12-12_2023-12-17.csv',40,1,'Hoàn thành','2023-12-12 11:49:29','2023-12-12 06:00:00','2023-12-17 03:00:00','Hoàn thành','2023-12-12 11:48:50','2023-12-12 11:49:29','huudan','huudan'),(30,'2023-12-12_2023-12-17.csv',40,1,'Hoàn thành','2023-12-12 20:55:48','2023-12-12 15:00:00','2023-12-17 12:00:00','Hoàn thành','2023-12-12 20:54:26','2023-12-12 20:55:48','huudan','huudan'),(31,'2023-12-12_2023-12-17_1.csv',NULL,1,'Bắt đầu chạy','2023-12-12 20:58:22','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 20:58:22','2023-12-12 20:58:22','huudan','huudan'),(32,'2023-12-12_2023-12-17_1.csv',NULL,1,'Bắt đầu chạy','2023-12-12 20:58:49','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 20:58:49','2023-12-12 20:58:49','huudan','huudan'),(33,'2023-12-12_2023-12-17.csv',NULL,1,'Bắt đầu chạy','2023-12-12 21:02:02','2023-12-12 15:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 21:02:02','2023-12-12 21:02:02','huudan','huudan'),(34,'2023-12-12_2023-12-17.csv',40,1,'Hoàn thành','2023-12-12 21:04:28','2023-12-12 15:00:00','2023-12-17 12:00:00','Hoàn thành','2023-12-12 21:03:44','2023-12-12 21:04:28','huudan','huudan'),(35,'2023-12-12_2023-12-17_1.csv',40,1,'Hoàn thành','2023-12-12 21:07:55','2023-12-12 15:00:00','2023-12-17 12:00:00','Hoàn thành','2023-12-12 21:07:12','2023-12-12 21:07:55','huudan','huudan'),(36,'2023-12-12_2023-12-17_2.csv',NULL,1,'Bắt đầu chạy','2023-12-12 21:09:22','2023-01-01 00:00:00','2023-01-31 00:00:00','Bắt đầu chạy','2023-12-12 21:09:22','2023-12-12 21:09:22','huudan','huudan'),(37,'2023-12-12_2023-12-17_2.csv',40,1,'Hoàn thành','2023-12-12 21:10:16','2023-12-12 15:00:00','2023-12-17 12:00:00','Hoàn thành','2023-12-12 21:09:26','2023-12-12 21:10:16','huudan','huudan'),(38,'2023-12-12_2023-12-17.csv',2560,1,'Hoàn thành','2023-12-12 21:15:38','2023-12-12 15:00:00','2023-12-17 12:00:00','Hoàn thành','2023-12-12 21:13:07','2023-12-12 21:15:38','huudan','huudan'),(39,'2023-12-13_2023-12-18.csv',2560,1,'Hoàn thành','2023-12-13 15:32:33','2023-12-13 09:00:00','2023-12-18 06:00:00','Hoàn thành','2023-12-13 15:29:18','2023-12-13 15:32:33','huudan','huudan'),(40,'2023-12-15_2023-12-20.csv',2560,1,'Hoàn thành','2023-12-15 13:34:24','2023-12-15 09:00:00','2023-12-20 13:30:43','Hoàn thành','2023-12-15 13:30:44','2023-12-15 13:34:24','huudan','huudan'),(41,'2023-12-15_2023-12-20_1.csv',2560,1,'Hoàn thành','2023-12-15 13:58:32','2023-12-15 09:00:00','2023-12-20 13:55:50','Hoàn thành','2023-12-15 13:55:50','2023-12-15 13:58:32','huudan','huudan'),(42,'2023-12-15_2023-12-20_2.csv',2560,1,'Hoàn thành','2023-12-15 14:03:41','2023-12-15 09:00:00','2023-12-20 14:00:13','Hoàn thành','2023-12-15 14:00:14','2023-12-15 14:03:41','huudan','huudan'),(43,'2023-12-15_2023-12-20_3.csv',2560,1,'Hoàn thành','2023-12-15 14:12:13','2023-12-15 09:00:00','2023-12-20 14:08:35','Hoàn thành','2023-12-15 14:08:35','2023-12-15 14:12:13','huudan','huudan'),(44,'2023-12-15_14:16:21_2023-12-20.csv',0,1,'Bắt đầu chạy','2023-12-15 14:16:21','2023-12-15 14:16:21','2023-12-15 14:16:21','Bắt đầu chạy','2023-12-15 14:16:21','2023-12-15 14:16:21','huudan','huudan'),(45,'2023-12-15_14:18:36_2023-12-20.csv',0,1,'Bắt đầu chạy','2023-12-15 14:18:37','2023-12-15 14:18:37','2023-12-15 14:18:37','Bắt đầu chạy','2023-12-15 14:18:37','2023-12-15 14:18:37','huudan','huudan'),(46,'2023-12-15_14:19:01_2023-12-20.csv',0,1,'Bắt đầu chạy','2023-12-15 14:19:02','2023-12-15 14:19:02','2023-12-15 14:19:02','Bắt đầu chạy','2023-12-15 14:19:02','2023-12-15 14:19:02','huudan','huudan'),(47,'2023-12-15_14:19:12_2023-12-20.csv',2560,1,'Hoàn thành','2023-12-15 14:22:34','2023-12-15 09:00:00','2023-12-20 14:19:12','Hoàn thành','2023-12-15 14:19:13','2023-12-15 14:22:34','huudan','huudan'),(48,'2023-12-15_14:31:12_2023-12-20.csv',0,1,'Bắt đầu chạy','2023-12-15 14:31:13','2023-12-15 14:31:13','2023-12-15 14:31:13','Bắt đầu chạy','2023-12-15 14:31:13','2023-12-15 14:31:13','huudan','huudan'),(49,'2023-12-15_14:33:09_2023-12-20.csv',0,1,'Bắt đầu chạy','2023-12-15 14:33:10','2023-12-15 14:33:10','2023-12-15 14:33:10','Bắt đầu chạy','2023-12-15 14:33:10','2023-12-15 14:33:10','huudan','huudan'),(50,'2023-12-15_14:36:45_2023-12-20.csv',40,1,'Bắt đầu chạy','2023-12-15 14:36:45','2023-12-15 09:00:00','2023-12-20 14:36:45','Đã chạy xong 40 dòng','2023-12-15 14:36:45','2023-12-15 14:37:28','huudan','huudan'),(51,'2023-12-15_14:51:56_2023-12-20.csv',12,1,'Bắt đầu chạy','2023-12-15 14:51:56','2023-12-15 09:00:00','2023-12-20 14:51:56','Đã chạy xong 12 dòng','2023-12-15 14:51:56','2023-12-15 14:52:35','huudan','huudan'),(52,'2023-12-15_14:55:55_2023-12-20.csv',0,1,'Bắt đầu chạy','2023-12-15 14:55:55','2023-12-15 14:55:55','2023-12-15 14:55:55','Bắt đầu chạy','2023-12-15 14:55:55','2023-12-15 14:55:55','huudan','huudan'),(53,'2023-12-15_14:56:19_2023-12-20.csv',40,1,'Bắt đầu chạy','2023-12-15 14:56:19','2023-12-15 09:00:00','2023-12-20 14:56:19','Đã chạy xong 40 dòng','2023-12-15 14:56:19','2023-12-15 14:56:56','huudan','huudan'),(54,'2023-12-15_14:58:54_2023-12-20.csv',40,1,'Bắt đầu chạy','2023-12-15 14:58:55','2023-12-15 09:00:00','2023-12-20 14:58:54','Đã chạy xong 40 dòng','2023-12-15 14:58:55','2023-12-15 14:59:38','huudan','huudan'),(55,'2023-12-15_15:05:08_2023-12-20.csv',40,1,'Bắt đầu chạy','2023-12-15 15:05:09','2023-12-15 09:00:00','2023-12-20 15:05:08','Đã chạy xong 40 dòng','2023-12-15 15:05:09','2023-12-15 15:06:01','huudan','huudan'),(56,'2023-12-15_15:12:57_2023-12-20.csv',40,1,'Bắt đầu chạy','2023-12-15 15:12:58','2023-12-15 09:00:00','2023-12-20 15:12:57','Đã chạy xong 40 dòng','2023-12-15 15:12:58','2023-12-15 15:13:38','huudan','huudan'),(57,'2023-12-15_15:14:55_2023-12-20.csv',40,1,'Bắt đầu chạy','2023-12-15 15:14:56','2023-12-15 09:00:00','2023-12-20 15:14:55','Đã chạy xong 40 dòng','2023-12-15 15:14:56','2023-12-15 15:15:42','huudan','huudan'),(58,'2023-12-15_15:48:38_2023-12-20.csv',2560,1,'Hoàn thành','2023-12-15 15:54:13','2023-12-15 09:00:00','2023-12-20 15:48:38','Hoàn thành','2023-12-15 15:48:38','2023-12-15 15:54:13','huudan','huudan'),(59,'2023-12-16_06:56:27_2023-12-21.csv',0,1,'Bắt đầu chạy','2023-12-16 06:56:27','2023-12-16 06:56:27','2023-12-16 06:56:27','Bắt đầu chạy','2023-12-16 06:56:27','2023-12-16 06:56:27','huudan','huudan'),(60,'2023-12-16_06:57:35_2023-12-21.csv',2560,1,'Hoàn thành','2023-12-16 07:00:36','2023-12-16 00:00:00','2023-12-21 06:57:35','Hoàn thành','2023-12-16 06:57:35','2023-12-16 07:00:36','huudan','huudan'),(61,'2023-12-16_12:48:20_2023-12-21.csv',2560,1,'Hoàn thành','2023-12-16 12:51:20','2023-12-16 06:00:00','2023-12-21 12:48:20','Hoàn thành','2023-12-16 12:48:21','2023-12-16 12:51:20','huudan','huudan');
/*!40000 ALTER TABLE `data_files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-16  6:42:46
